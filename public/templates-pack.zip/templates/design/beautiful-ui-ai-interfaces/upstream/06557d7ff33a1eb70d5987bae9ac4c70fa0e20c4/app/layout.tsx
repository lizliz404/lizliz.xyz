import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import { DialRoot } from "dialkit";
import "dialkit/styles.css";
import "./globals.css";
import { DevToolbar } from "@/components/site/DevToolbar";
import { EmailNudge } from "@/components/site/EmailNudge";
import { InteractionSounds } from "@/components/site/InteractionSounds";
import { ThemeSync } from "@/components/site/ThemeSync";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono-face",
});

export const metadata: Metadata = {
  title: "Beautiful UI — Crafted primitives for AI-native interfaces",
  description:
    "A small library of extremely crafted, copy-paste components for chat agents, thinking states, human-in-the-loop approvals, and everything agents need to talk to humans beautifully.",
};

const themeScript = `(function(){try{var t=localStorage.getItem("bui-theme");document.documentElement.classList.toggle("dark",t!=="light")}catch(e){document.documentElement.classList.add("dark")}})()`;

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className={`${inter.variable} ${mono.variable} font-sans`}>
        <ThemeSync />
        <InteractionSounds />
        <EmailNudge />
        {children}
        {/* DialKit is a dev-only tuning panel — never render it in production. */}
        {process.env.NODE_ENV === "development" && (
          <DialRoot position="top-right" defaultOpen />
        )}
        <DevToolbar />
      </body>
    </html>
  );
}
