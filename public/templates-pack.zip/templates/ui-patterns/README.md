# UI micro-patterns

这里放可单独取用的小机制，不放完整视觉系统。任务总路由在 [`../README.md`](../README.md)；Beautiful UI 不在本目录，而在 `design/`，它是 Agent thinking chrome 的相邻兄弟资产。

## Product craft

- **Data-dense B2B app craft** → [`data-dense-app-craft.md`](./data-dense-app-craft.md) + [`data-dense-b2b-app.md`](./data-dense-b2b-app.md)：tables、filters、forms、inboxes、dashboards、admin。
- **AI workspace surfaces** → [`ai-workspace-surfaces.md`](./ai-workspace-surfaces.md)：Workspace 常驻切换与管理、主对象 + 右侧 Agent rail、低优先级 Activity 聚合、Board drag/edit/side peek，以及 Stepper → Mermaid → React Flow 可视化梯子；单个 chat 状态走 `../agentic-ui-primitives.md`。
- **Multi-pane scroll architecture** → [`multi-pane-scroll-architecture.md`](./multi-pane-scroll-architecture.md)：壳锁 100dvh、每栏自滚 + `overscroll-behavior: contain` 断链、画布自吃 wheel、聊天「在底部才跟滚」+ 跳底 pill、hover+focus 行内动作、auto-fill/容器查询卡片网格、M3 断点 rail/抽屉化；修多栏滚动耦合先读它，页面编排仍走上一行，画布对象协议走 `../artifacts-canvas-workbench.md`。
- **Icon system craft** → [`icon-system-craft.md`](./icon-system-craft.md)：Track A product chrome 的线重、尺寸与概念表；稳定生产线与 authored exceptions 分工；不是 favicon / wordmark / OG。
- **Runeicons authoring workbench** → [`runeicons-authoring-workbench.md`](./runeicons-authoring-workbench.md)：与 Iconoir 同为一等图标决策候选；当前只作 Apache-2.0 路径编辑、五 style 与 SVG/JSX 动效导出工作台，未发布 packages 不进 runtime。
- **Interface audit → refine toolchain** → [`interface-audit-refine-toolchain.md`](./interface-audit-refine-toolchain.md)：Jakub Interfaces skills 负责跨域审计与修复；Libraries.dev 与 Astryx 只填已证明的效果 / 组件缺口；Light Rails 只做许可隔离的单层 motion spike。
- **Recover at point of failure** → [`recover-at-point-of-failure.md`](./recover-at-point-of-failure.md)：系统消息按 L0–L3 可执行性分级，失败点就地恢复；PACK DOCTRINE + EVIDENCE 双轨标注。
- **Consent gate** → [`consent-gate.md`](./consent-gate.md)：条款 / 隐私 / 营销同意流的三策略与选择轴，recover 学派的具体应用。
- **Search craft** → [`search-craft.md`](./search-craft.md)：Search、Filter、Cmd+K 与按产品类型选引擎。
- **Searchable filter choice** → [`searchable-filter-choice.md`](./searchable-filter-choice.md)：筛选菜单里输入过滤与点选共存的单/多选合同——过滤绝不改已选值、已选标签与取消入口始终可达；列表置顶/草稿去留/匹配语义属声明过的 POLICY；含常驻行不计匹配、IME Enter、接法取舍与验收清单。
- **SaaS onboarding two-phase** → [`saas-onboarding-two-phase.md`](./saas-onboarding-two-phase.md)：B2B / Agent 的 aha 之后才进入生产设置。
- **Publish calendar** → [`publish-calendar/SKILL.md`](./publish-calendar/SKILL.md)：发布/排期月历的 MUST/POLICY/PROFILE 分层合同、四层 DOM/ARIA 结构、Aurora 示例 profile 与不与 shell hotkeys 冲突的键盘合同；页面级工作台，不是 date picker。
- **Linear method philosophy** → [`linear-method-philosophy.md`](./linear-method-philosophy.md)：产品哲学纯复用层——八原则 + 方法流 + 七对象 + 取舍纪律；项目映射不进 pack。
- **Agent interaction guidelines** → [`agent-interaction-guidelines.md`](./agent-interaction-guidelines.md)：Agent 交互契约纯复用层——六原则 + Session×Activity + delegation + 时序合同 + loops；项目选型不进 pack。
- **Quote into composer** → [`quote-into-composer.md`](./quote-into-composer.md)：划选回复/点对象图 → 单钮浮条 → composer 上紧凑 chip → 发送后同族引用块可点回源；引用是有锚点的对象不是注入文本，含 chip/发送/锚点三层合同；不是 `>` blockquote 手打。

## Motion chrome

- **AI thinking orb** → [`ai-thinking-orb/SKILL.md`](./ai-thinking-orb/SKILL.md)：landing 或 Agent surface 上只放一个环境状态球（上游源码与移植 recipe 已收进包）；不与 live Paper shader 叠加。
- **Beautiful UI primitives** → [`../design/beautiful-ui-ai-interfaces/`](../design/beautiful-ui-ai-interfaces/)：本目录之外的同族资产，提供 thinking、streaming、approval、tables 等可挑选的 Agent DOM 原语。
- **Paper Shaders** → [`../paper-shaders/SKILL.md`](../paper-shaders/SKILL.md)：本目录之外的背景氛围配方；不是 orb，也不承担状态语义。
- **ThreeUI hero** → [`threeui-hero-adapter.md`](./threeui-hero-adapter.md)：一个 MIT Community 3D product hero；说明图仍走 visual-economy。
- **Drafting resolve hero** → [`drafting-resolve-hero.md`](./drafting-resolve-hero.md)：虚线草图 → 实线成稿的注意力 resolve 线稿 hero；完整三源考察与机制在 webgl-threejs-background-animation skill 的 references。
- **UI SFX cues** → [`uisfx-semantic-cues.md`](./uisfx-semantic-cues.md)：语义界面声音完整纪律——pack 选型法、cue 语义映射、播放器生命周期、loop 清理、声音偏好；必须有同时可见的状态。
- **Amicro motion registry intake** → [`amicro-motion-registry-intake.md`](./amicro-motion-registry-intake.md)：162-item MIT React registry 的按件筛选闸；只填真实状态缺口，不装整套、不抄 showcase motion。
- **Proof-first launch storyboard** → [`proof-first-launch-storyboard.md`](./proof-first-launch-storyboard.md)：proof-first hook、关系装配、后置 tension、单句 payoff 的产品片四拍。
- **Progressive 3D assembly** → [`progressive-assembly-3d.md`](./progressive-assembly-3d.md)：一动作一块、k/N、pause/rotate/zoom 和 2D fallback；把 3D 变成状态解释器而非装饰球。
- **Liquid gooey micro-interactions** → [`liquid-gooey-micro-interactions.md`](./liquid-gooey-micro-interactions.md)：React 液滴黏滞融合微交互（npm `liquid-gooey`，MIT）；小面积 chrome 的手感层，剪影层过滤镜、内容层保持清晰；不承担语义状态。
- **Hand-drawn controls** → [`hand-drawn-controls.md`](./hand-drawn-controls.md)：drawably（MIT）手绘 boiling 控件；seeded SVG 叠在真控件下，a11y 来自真控件；playful 表面专用，dense B2B admin 换资产。
- **Playful isometric empty states / 角色微交互家族** → [`playful-isometric-empty-states.md`](./playful-isometric-empty-states.md)：四种线稿空状态，分层与短时序；同家族 dog / hamster 的触发机制对照与 Hairline 选型。
- **Hamster cookie consent** → [`hamster-cookie-consent.md`](./hamster-cookie-consent.md) + [`snippets/hamster-cookie-consent.html`](./snippets/hamster-cookie-consent.html)：同意项映射为投喂仓鼠；与 stretchy-dog 同作者；学习用手艺，生产慎用。
- **Stretchy dog password meter** → [`stretchy-dog-password-meter.md`](./stretchy-dog-password-meter.md) + [`snippets/stretchy-dog-password-meter.html`](./snippets/stretchy-dog-password-meter.html)：单一指标映射为真实变长的角色，表情 / 文案分档与奖励态；playful 表面专用。
- **vgpu WebGPU effects** → [`vgpu-webgpu-effects.md`](./vgpu-webgpu-effects.md)：vercel-labs 的 WebGPU 渲染库（typed WGSL 导入、单 `Gpu` 上下文、按版本与入口实测包体、browser / node / mock 三运行时）；orb / Paper / ThreeUI 覆盖不到的自定义 shader 特效施工层，WebGPU-only 无自动兜底。

## Landing chrome

- **Footer craft** → [`footer-craft.md`](./footer-craft.md)：营销长页的收口。
- **Premium one-pager** → [`premium-one-pager.md`](./premium-one-pager.md) + [`snippets/`](./snippets/)：长营销页或文档的 location / life / finish。
- **会定格、可采纳的示例占位符** → [`typing-placeholder-animation.md`](./typing-placeholder-animation.md)：条目 40 的当前合同，点击冻结、显式写入草稿；[`snippets/`](./snippets/) 中的 typewriter 仍是旧版基础轮播，不含采纳流程。
- **Atomic island chrome** → [`atomic-island-chrome.md`](./atomic-island-chrome.md)：full-bleed camera / canvas / toy 的可收起 chrome，不适合需要持续导航的 dense desktop shell。
- **Landing CTA economy** → [`landing-cta-economy.md`](./landing-cta-economy.md)：按「竞争的下一步」做预算而不是按按钮个数；CTA 重复的权重递减、首屏与段落字数上限、hedge 三类与五问判据；定价页与受监管品类有例外。
- **Scroll-shrink glass capsule nav** → [`scroll-shrink-glass-capsule-nav.md`](./scroll-shrink-glass-capsule-nav.md)：整条透明导航滚动后收成居中玻璃胶囊的三档实现（CSS blur / SVG 折射 / WebGL）、最坏背景对比度算法、四路降级与 iOS blur 边界；点按展开的岛式 chrome 走上一行。
- **Ask ChatGPT 外部跳转入口（chatgpt.com/?q 预填）** → [`ask-chatgpt-entry.md`](./ask-chatgpt-entry.md)：q= 预填参数与限制、pin 条/内联行/按钮三形态、诚实文案规则与降级阶梯；站内助手并存模式，不是站内搜索入口。
- **Header nav + jump bar（下划线 replay / chromeless dropdown / 实测 header 高 / scrollspy）** → [`header-nav-and-jump-bar.md`](./header-nav-and-jump-bar.md) + [`snippets/header-nav-and-jump-bar.html`](./snippets/header-nav-and-jump-bar.html)：双程下划线 replay、`:has()` 零 markup 整页 scrim、`--header-h` 运行时同步、`aria-current="location"` 页内 scrollspy；含 hover 死带 / band 空态 / 强制状态污染三个实测缺陷与修法，可运行演示即骨架。

## 使用与维护

1. 按任务和表面类型选择一行，先读它的 “When / when not”。
2. 只复制验证信号需要的机制，并适配项目 `DESIGN.md`。
3. 跑该模式的检查；构建通过不能代替视觉 QA。
4. 新增、修改、删除规则以 [`../README.md`](../README.md) 为准；这里只为 micro-pattern 保留一条本地行。

灵感书签（不是资产）：[`../inspiration-sources.md`](../inspiration-sources.md)。
