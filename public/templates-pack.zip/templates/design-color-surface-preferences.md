# Color & Surface Preferences

类型：Craft convention（与 [`design-typography-font-preferences.md`](./design-typography-font-preferences.md) 同级；**不是** checklist 条目全文）

Checklist §40 只留指针。数字、色温、证据、杀掉标准只维护本文。改色先完整读消费项目 canonical `DESIGN.md`，核对生效约束，再按需读本文与动 `:root`；候选不因出现在资产里而生效。

**原站实测而非主题批准**：[Anduril / Saronic DNA](./design/anduril-saronic-dna.md) 保存黑/纸与 midnight/sunlight 原始 HEX、强调色用途、实际 seam 与 token 的差异和对比计算。原站纯黑/浅底是研究事实，不受本文改写；本文的工作面默认也不被原站色板自动覆盖。未测像素面积就不报“≥90%中性色”。

| | |
|---|---|
| **What** | 页面底 / 卡片 / 侧栏 / 弹层 / 正文墨，禁止纯白纯黑铺底；按产品类型选「微色相壳」或「米黄纸」。 |
| **Why** | 避免默认纯黑白，给长会话选择更克制的表面与墨色。舒适度仍受显示器亮度、环境光、字体、个人差异影响；不能用某个 HEX 承诺护眼或防疲劳。改一组 token 一杯咖啡。 |
| **Who** | 日用工具、OA、后台、阅读面。营销极简页可以把刺当意图，那是例外。 |
| **Not this** | 不是医学护眼结论；不是 dark-mode 专题；不是「所有产品都做成 Notion」。品牌配色只给复用与语义接线方法，不替项目拍板。 |

证据层：Exa 检索 2026-08-14（见文末）。配方层：Liz 盯表产品（出海云 / 前程预算）要走米黄纸，不是冷灰白。

---

## 硬禁（铺底）

不要用这些做 **page / card / sidebar / popover / sheet** 实底：

- `#FFFFFF` / `#000000`
- `oklch(1 0 0)` / `oklch(0 0 0)`
- `bg-white` / `bg-black` 铺满
- `rgba(255,255,255,1)` 以及 **α≥0.85 的纯白盖在浅底上**（眼睛仍当它是白；透明度不是豁免）

正文不要 `#000`。Dark 底不要 `#0a0a0a` 装高级（还是洞）。

**不是铺底、允许纯白/纯黑：** 彩色填充上的字、视频烧录字幕、logo 反白、玻璃高光 1px、品牌花标的高光边（如前程 `data-mark-tone='inverse'` 的 `--mark-edge`）。

---

## 两条带（按场景选，不要混）

「最多人用」和「盯表最站得住」不是同一套。Carbon / MUI / 默认 shadcn 仍大量 `#FFF`——那是出货惯性，不是护眼结论。

| 带 | 何时 | Paper | Card | Ink | 参照 |
|---|---|---|---|---|---|
| **A · 微色相壳** | 营销壳、短会话、品牌冷/蓝的仪表盘 chrome | L 0.96–0.98，C **0.004–0.010**，hue 跟品牌走 | 比 paper 略亮，**L&lt;1**，同色相 | L ≥ 0.22，带一点同色相 | Linear / Stripe / Vercel 那挂：冷灰白 `#F4F6FA`、`#F8F9FA` |
| **B · 米黄纸（盯表）** | 人要连续盯几小时的工作面：预算 OA、出海云后台、阅读/填报 | L **0.94–0.97**，C **0.012–0.022**，hue **70–95** | L **0.98–0.985**，C **0.008–0.012**，**同一暖相** | L **0.26–0.32**，C **0.018–0.028**，hue **50–70**（暖近黑，Notion `#37352F` 一族） | Notion `#F7F6F3`；BDA cream；Kindle sepia 的克制版 |

出海云有蓝紫极光、预算系统没有品牌蓝——**工作面都走 B**。品牌色放在 primary / 极光 / focus，不要把纸也染成冷蓝灰。

**不要：** 米黄底 + 纯白卡（两套灯光）。Card 必须同暖相、只是更亮。

**A 带的合法冷底：** 短会话、明确要「实验室/工具」信号。一旦用户日盯 ≥1h，改 B。

---

## 配方（直接抄）

OKLCH。Hex 只给对照，真源是 oklch。

### B 带 · 盯表（出海云工作面 + 前程预算默认）

```css
:root {
  --background: oklch(0.96 0.016 85);   /* 米黄往白偏的纸 */
  --card:       oklch(0.985 0.008 85);  /* 仍 L<1，同暖相 */
  --popover:    oklch(0.982 0.009 85);
  --sidebar:    oklch(0.95 0.014 85);
  --muted:      oklch(0.935 0.014 85);
  --border:     oklch(0.88 0.016 85);
  --foreground: oklch(0.28 0.022 60);   /* 暖近黑 */
  --muted-foreground: oklch(0.45 0.02 60);
}
.dark {
  --background: oklch(0.20 0.016 60);   /* 抬起来的暖墨，不是洞 */
  --card:       oklch(0.25 0.018 60);
  --foreground: oklch(0.93 0.012 85);   /* 暖近白，不是 #FFF */
}
```

半透明卡（出海云）：`oklch(0.985 0.010 85 / 94%)` —— 色相走纸，α 走玻璃纪律；不要 `oklch(1 0 0 / 0.94)`。

对照 hex（约值，勿当真源）：paper `#F6F1E8`，card `#FBF8F3`，ink `#3A3228`。

### A 带 · 微色相壳（仅短会话 / 冷品牌壳）

```css
:root {
  --background: oklch(0.965 0.006 260);
  --card:       oklch(0.985 0.004 260);
  --foreground: oklch(0.26 0.012 260);
}
```

这是「避白」的地板，**不是**盯表目标。前程预算 2026-08-14 另一轮 agent 停在这档（hue 260 / C 0.003–0.004）——算避白，**不算纸**。

### 阴影跟色温

`box-shadow: … rgba(0,0,0,0.1)` 在暖纸上是洞。

- 暖纸：`rgba(100, 60, 30, 0.08)` 量级
- 冷壳：`rgba(30, 50, 100, 0.08)` 量级
- Dark：阴影变 luminance 边，仍不要纯黑贴纸

---

## 品牌配色：复用成熟答案，不重新做一轮调研

补充于 2026-10-10。来源：[`lizliz404/design`](https://github.com/lizliz404/design/tree/62a2528/2026-10-03-tech-romance) 的原始转录（§19:01–20:30）、`brief.md` 与图片分析的 Color Palette & Contrast 段。它们提出复用 One Dark Pro / Solarized / Claude 等成熟配色、分开底色与图案色；图片里的森林绿＋陶土橙是服装参考，色号和心理学解释是 AI 推测，**不是验证过的 UI 标准**。原件保留在源 repo；这里仅收可迁移方法，不复制原件、不让每个消费 Agent 重做研究。

### 选色顺序

1. **先场景，再来源**：长会话先定微暖低饱和表面；选一个已有、可核对的产品／编辑器色板作为品牌组合起点。项目已有认可主色时先扩展其色阶，不换整套。研究仓库提到的主题名是候选，不是已核验 HEX；取精确值时读上游主题 token，别凭截图猜。
2. **借关系，不照搬语义**：从现成组合取中性底、墨色、主强调、少量次强调；编辑器语法色、服装印花色不自动等于 success / warning / error，更不能把代码主题的深底搬成浅色工作面。
3. **同色系分角色**：primary 是 CTA 填充；link / focus 用较深阶；hover / pressed 独立阶；wash 是浅选中底；mid / edge 是图形和轻分隔。浅 edge 不能承担唯一的控件识别或必要 focus；品牌蓝不要求中性纸也偏蓝。
4. **第三色先问用途**：只增加一个有实际位置的 accent 色系；可复用来源的互补／邻近关系，但用少量面积与较低彩度控制抢焦点。第三色不抢主 CTA、不冒充成功绿／告警琥珀；没有具体用途先不加。小面积不是对比度豁免。
5. **验组合而非单色**：正文／辅助字对最终合成底色至少 4.5:1；大字 3:1；必要控件边界／focus 与相邻色至少 3:1（WCAG 2.2 AA，非舒适度处方）。透明 wash、卡面、图像上的字须按实际合成检查；状态保留文字／图标，不仅靠 hue。最后看桌面和窄屏真实页面，而非只看色卡。

### 低成本接线：primitive → semantic → component

```css
:root {
  /* 唯一调色入口：primitive，值来自项目选择 */
  --palette-paper: oklch(0.961 0.009 85);
  --palette-brand: oklch(0.535 0.22 270);
  --palette-brand-deep: oklch(0.463 0.198 267);
  /* 稳定页面 API：semantic，组件不认识具体色号 */
  --background: var(--palette-paper);
  --primary: var(--palette-brand);
  --link: var(--palette-brand-deep);
  --ring: var(--palette-brand-deep);
}
```

- 换色：改 primitive；CSS aliases 和组件保持稳定。明天增加第三色：在同一 token 文件增加 accent primitive + 该用途的 fill / ink / wash aliases，再让少数对应组件消费，**不用全站替换色号**。不要提前造无用途的色系枚举或主题引擎。
- 语义状态色、平台标识、图表数据、视频字幕／相机面独立，换品牌不能连带改掉。
- palette 文件负责数值和 aliases；全局样式负责材质／排版；组件只负责用途。小项目可保留一份 CSS，大文件按职责抽出一份 token CSS，不复制两套 palette。
- CSS variable 在声明作用域解析。支持 `.dark` 或局部主题时，让 aliases 也在主题作用域重新解析；仅覆盖子节点 primitive 不保证从祖先继承的 alias 随之改变。
- `DESIGN.md` 是消费项目唯一设计合同，改动与 token 同步进入 Git；不另开正式版／方案版。它不在运行时解析成 CSS，不加自动同步系统。
- 复用到此即止：读本篇 + 选定来源的相关 token，记录决定并实现。只有存在具体证据缺口才查来源，不把模板消费变成重复 due diligence。

---

## 怎么落到一个 repo

1. 先定带：日盯 → B；否则 A。
2. 改 `:root` / `.dark` 的 **surface + ink 中性轴**。语义色（destructive / warn / success / 品牌 primary / 极光）不动，除非它本身是 `#000`/`#FFF` 铺底。
3. 扫：`bg-white`、`bg-black`、`#fff`、`#ffffff`、`oklch(1 0 0)`、`oklch(0 0 0)` 铺底。漏网的 85% 白遮罩一起改。
4. DESIGN.md / `DESIGN.system.md` 的 hex 与 YAML **跟着 token 改**，禁止文档还写 `#ffffff` 而 CSS 已经是纸。
5. 并排看：笔记本高亮 + 外接屏。杀掉标准见下。
6. 品牌主色、图表语义色、平台色（TikTok 红等）不在本文范围。

**出海云特判：** 极光 `body::before` 保持蓝紫低 α。变的是纸/卡/墨。极光是窗，纸是桌。不要把 `--background` 继续停在 hue 258。

**前程预算特判：** `docs/DESIGN.system.md` 里「不是 Soft Editorial cream」指的是 **禁止编辑风衬线/鎏金**，不是禁止纸色底。工作面走 B 带。Geist 灰阶营销页那套 `gray-1000` + 纯中性，不再当预算 OA 的纸。

---

## 反模式

| 做法 | 为什么不行 |
|---|---|
| `#FAFAFA` / `zinc-50` 无色相 | 近白，仍是没调过 |
| `oklch(0.96 0.004 260)` 声称「已经是纸」 | 冷蓝灰微偏；屏幕边上看不出；盯表仍刺 |
| C &gt; 0.03 或 L &lt; 0.94 的「米黄」 | 脏、旧 Excel、咖啡渍 |
| 暖纸 + 冷阴影 / 纯黑阴影 | 色温打架 |
| 暖纸 + `oklch(1 0 0)` 卡 | 灯不一样 |
| 把唯一 CTA 做成低对比暖灰 | 本文管铺底，不管把按钮藏起来 |
| 控制室 HMI 的浅灰当预算表圣经 | HMI 灰是为了让报警色跳；OA 的红/琥珀是局部 chip，纸色吃不掉 |

---

## 杀掉标准

- 财务 / 运营说「黄了、脏了、像旧表格」→ 退到 Notion 附近：C **0.008–0.010**，hue 仍 85，**不要退回 hue 260**。
- 对比不够、字发飘 → 先降 ink 的 L，不要把纸推回 `#FFF`。
- WCAG 正文对纸仍须 ≥4.5:1。12:1–16:1 可作为本配方的设计比较范围，不是医学舒适区；21:1 也不是必须追求的阅读目标。

---

## 证据（Exa · 2026-08-14）

检索问题：纯白纯黑是否最佳实践；最多人用的是哪套；盯表要不要更冲的米黄。

**出货量（惯性，不是结论）**

- IBM Carbon White theme、MUI 默认、大量 shadcn 起步板：画布仍 `#FFFFFF`。Dataface 文档也承认「纯白当卡面仍然常见」。
- 这是「没选」的默认，不是长时间阅读的最优。

**做工向 SaaS（A 带）**

- Linear / Stripe / Vercel 评论共识：不用纯中性；中性带 2–3% 品牌色相；阴影带色温（UX Planet 2026-03，Usman Writes）。
- 他们多数落地是**冷灰白**，不是奶油。Mantlr 提醒：不要把「永远 #2A2A2A」写成这三家没写过的教条；温度跟品牌走。
- 前程预算若抄 Geist 营销灰，会得到 A 带冷壳——适合 Vercel 站，不适合盯账。

**长时间盯字 / 盯表（B 带，本文对 OA 的主结论）**

- British Dyslexia Association Style Guide：白底「too dazzling」；cream / soft pastel；深色字但不要纯黑。
- 历史检索曾转述 Rello 等阅读研究与暖底偏好；本篇未保留该研究的直接链接、样本及适用条件，不能据此声称暖底普遍更护眼。WCAG 要求足够对比，不等于医学最佳背景色。
- Notion 可识别底 `#F7F6F3`（HSL ~45° / 22% / 96%）：几乎白，但明确是奶油纸。对照 Google Docs `#FFF`（临床）、Confluence `#F4F5F7`（公司冷灰）。
- Colorhero / ColorArchive：`#000` 对 `#FFF` = 21:1，halation（字边发晕）；正文近黑 + off-white/cream，对比大约 12:1–17:1。
- Kindle / reader mode：默认 sepia，不是 `#FFF`。屏幕发光 ≠ 纸反光。
- 控制室 HMI（Center for Operator Performance）：常用浅灰/浅蓝，**明确说不要纯白**；那是为报警色服务的无彩画布。OA 局部语义色不需要把整张纸洗成灰。

**和「品牌冷蓝所以纸也要蓝」的冲突**

A 带逻辑：蓝品牌 → 中性微蓝。出海云已经有蓝紫极光当品牌场，再把纸做成 hue 258，一整天都是荧光办公室。B 带：极光=窗，纸=桌。品牌蓝留在 primary / 授权 / 极光。

---

## 和清单、字体篇的关系

- [`high-leverage-craft-checklist.md`](./high-leverage-craft-checklist.md) §41：一句话禁令 + 链到本文。不要把本文数字抄回 checklist。
- [`design-typography-font-preferences.md`](./design-typography-font-preferences.md)：选字体。本文选铺底。两件事一起才构成「不是浏览器默认」。
- 附 A 纸纹/材质：纹理叠加在已经正确的纸色上；先色后纹。
