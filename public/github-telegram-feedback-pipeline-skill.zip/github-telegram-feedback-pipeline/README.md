# GitHub Telegram Feedback Pipeline

Same-origin Cloudflare Pages feedback widget → GitHub Issues and/or Telegram.

Public name: **GitHub Telegram Feedback Pipeline**  
Skill id: `github-telegram-feedback-pipeline`

Drop the folder into your agent skills directory. Copy `references/feedback-function.ts` and `references/FeedbackWidget.tsx` into a CF Pages project, set env vars, redeploy.

Default feedback Telegram group (Liz): `-5544201640` (title: GitHub).

See `SKILL.md` for the full workflow.

MIT via the parent agent-skills repo.
