# DESIGN.md Visual System — skill pack

Implementation-grade **Genre A** DESIGN.md authoring for coding agents: YAML tokens + prose (Signature Treatments, Defaults, Do/Don't, CJK, Iteration, Known Gaps).

## Contents

```
design-md-visual-system/
├── SKILL.md
├── README-PACK.md          ← this file
└── references/
    ├── anatomy-and-patterns.md
    ├── quality-rubric.md
    └── skeleton.md
```

## Install

Unpack into your agent skills directory as `design-md-visual-system/` (Hermes / Claude Code / Cursor skills folder — match your runtime).

## Gold corpus (not in this pack)

Reference examples live in the local tool **`beautiful-html-templates`** at `templates/*/design.md` (start with `soft-editorial`). That corpus is a separate operator-local asset and is intentionally **not** bundled here.

## CLI

```bash
npx -y @google/design.md lint DESIGN.md
npx -y @google/design.md export --format dtcg DESIGN.md
npx -y @google/design.md export --format css-tailwind DESIGN.md
```

Upstream format: https://github.com/google-labs-code/design.md

## Genre boundary

- **A (this skill):** UI visual system agents can implement.
- **B:** Brand / OG / image-gen briefs — use separate design-brief skills; do not collapse into one thin file.

## Version

Skill pack `1.0.0` (see SKILL.md frontmatter). Google DESIGN.md file `version:` fields typically remain `alpha` per upstream format.
